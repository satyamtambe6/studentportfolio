/* ============================================================
   SATYAM TAMBE PORTFOLIO — script.js
   ============================================================ */

// ===== TYPING ANIMATION =====
const roles = [
  "Computer Engineering Student",
  "Web Developer",
  "Java & C++ Programmer",
  "DSA Learner",
  "Problem Solver"
];
let roleIndex = 0, charIndex = 0, isDeleting = false;
const typingEl = document.getElementById("typingText");

function typeEffect() {
  const currentRole = roles[roleIndex];
  if (!typingEl) return;
  if (!isDeleting) {
    typingEl.textContent = currentRole.slice(0, charIndex++);
    if (charIndex > currentRole.length) { isDeleting = true; setTimeout(typeEffect, 1800); return; }
  } else {
    typingEl.textContent = currentRole.slice(0, charIndex--);
    if (charIndex < 0) { isDeleting = false; roleIndex = (roleIndex + 1) % roles.length; setTimeout(typeEffect, 300); return; }
  }
  setTimeout(typeEffect, isDeleting ? 55 : 95);
}
typeEffect();

// ===== FADE-IN ON SCROLL =====
const fadeEls = document.querySelectorAll(".fade-in, .fade-in-delay");
const observer = new IntersectionObserver((entries) => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add("visible"); });
}, { threshold: 0.12 });
fadeEls.forEach(el => observer.observe(el));

// ===== PROGRESS BARS =====
const barObserver = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      const bar = e.target.querySelector(".progress-bar");
      if (bar) { const w = bar.getAttribute("data-width"); bar.style.width = w + "%"; bar.setAttribute("aria-label", w + "%"); }
    }
  });
}, { threshold: 0.3 });
document.querySelectorAll(".skill-card").forEach(card => barObserver.observe(card));

// ===== COUNTER ANIMATION =====
function animateCounter(el, target) {
  let current = 0;
  const step = Math.max(1, Math.ceil(target / 40));
  const interval = setInterval(() => {
    current = Math.min(current + step, target);
    el.textContent = current + "+";
    if (current >= target) clearInterval(interval);
  }, 40);
}
const statObserver = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      animateCounter(e.target, parseInt(e.target.getAttribute("data-target")));
      statObserver.unobserve(e.target);
    }
  });
}, { threshold: 0.5 });
document.querySelectorAll(".stat-number").forEach(el => statObserver.observe(el));

// ===== SCROLL TO TOP =====
const scrollBtn = document.getElementById("scrollTopBtn");
window.addEventListener("scroll", () => {
  scrollBtn.classList.toggle("visible", window.scrollY > 400);
});
scrollBtn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

// ===== NAVBAR ACTIVE ON SCROLL =====
const sections = document.querySelectorAll("section[id]");
const navLinks = document.querySelectorAll(".nav-pill");
window.addEventListener("scroll", () => {
  let current = "";
  sections.forEach(s => { if (window.scrollY >= s.offsetTop - 100) current = s.getAttribute("id"); });
  navLinks.forEach(link => {
    link.classList.remove("active");
    if (link.getAttribute("href") === "#" + current) link.classList.add("active");
  });
});

// ===== THEME TOGGLE =====
const themeToggle = document.getElementById("themeToggle");
const themeIcon = document.getElementById("themeIcon");
const htmlEl = document.documentElement;
themeToggle.addEventListener("click", () => {
  const isDark = htmlEl.getAttribute("data-theme") === "dark";
  htmlEl.setAttribute("data-theme", isDark ? "light" : "dark");
  themeIcon.className = isDark ? "bi bi-sun-fill" : "bi bi-moon-stars-fill";
});

// ===== CONTACT FORM MOCK SUBMIT =====
function sendMessage() {
  const name = document.getElementById("cName").value.trim();
  const email = document.getElementById("cEmail").value.trim();
  const msg = document.getElementById("cMsg").value.trim();
  if (!name || !email || !msg) {
    alert("Please fill in all required fields.");
    return;
  }
  const successEl = document.getElementById("successMsg");
  successEl.style.display = "block";
  setTimeout(() => { successEl.style.display = "none"; }, 5000);
  document.getElementById("cName").value = "";
  document.getElementById("cEmail").value = "";
  document.getElementById("cSubject").value = "";
  document.getElementById("cMsg").value = "";
}

// ===== SMOOTH SCROLL =====
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener("click", e => {
    const target = document.querySelector(a.getAttribute("href"));
    if (target) { e.preventDefault(); target.scrollIntoView({ behavior: "smooth", block: "start" }); }
  });
});
